<?php
return [
    'fields_not_accepted' => '欄位 :field 不支援搜尋功能'
];
