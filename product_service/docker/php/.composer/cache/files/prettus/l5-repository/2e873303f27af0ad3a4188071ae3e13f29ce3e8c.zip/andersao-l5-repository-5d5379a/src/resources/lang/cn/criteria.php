<?php
return [
    'fields_not_accepted' => '不接受的筛选字段 :field'
];
