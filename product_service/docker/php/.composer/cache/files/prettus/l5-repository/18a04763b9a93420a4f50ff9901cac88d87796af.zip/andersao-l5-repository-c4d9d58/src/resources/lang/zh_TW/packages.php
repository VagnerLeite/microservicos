<?php
return [
    'prettus_laravel_validation_required' => "需要其它套件。請安裝：'composer require prettus/laravel-validation'",
    'league_fractal_required'             => "需要其它套件。請安裝：'composer require league/fractal' (0.12.*)"
];
