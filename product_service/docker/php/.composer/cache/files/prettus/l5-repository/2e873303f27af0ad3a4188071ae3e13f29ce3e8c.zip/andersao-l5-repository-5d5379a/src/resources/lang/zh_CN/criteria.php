<?php
return [
    'fields_not_accepted' => '字段 :field 不支持搜索功能'
];
