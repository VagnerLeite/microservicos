<?php
return [
    'prettus_laravel_validation_required' => "需要其它组件。请安装：'composer require prettus/laravel-validation'",
    'league_fractal_required'             => "需要其它组件。请安装：'composer require league/fractal' (0.12.*)"
];
