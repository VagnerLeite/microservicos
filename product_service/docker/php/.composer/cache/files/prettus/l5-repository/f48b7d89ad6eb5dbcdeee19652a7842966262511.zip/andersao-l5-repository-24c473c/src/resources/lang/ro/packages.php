<?php
return [
    'prettus_laravel_validation_required' => "Pachet obligatoriu. Instalaţi prettus/laravel-validation ('composer require prettus/laravel-validation'), vă rog.",
    'league_fractal_required'             => "Pachet obligatoriu. Instalaţi league/fractal ('composer require league/fractal') (0.12.*), vă rog."
];
