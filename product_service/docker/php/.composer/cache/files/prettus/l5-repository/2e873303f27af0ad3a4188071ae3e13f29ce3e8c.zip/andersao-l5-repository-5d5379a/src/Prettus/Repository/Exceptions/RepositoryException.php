<?php
namespace Prettus\Repository\Exceptions;

use Exception;

/**
 * Class RepositoryException
 * @package Prettus\Repository\Exceptions
 * @author Anderson Andrade <contato@andersonandra.de>
 */
class RepositoryException extends Exception
{

}
