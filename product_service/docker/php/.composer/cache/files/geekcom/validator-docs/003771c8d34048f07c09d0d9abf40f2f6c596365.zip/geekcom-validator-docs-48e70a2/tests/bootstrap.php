<?php

include_once __DIR__ . '/../vendor/autoload.php';

include_once __DIR__ . '/../vendor/laravel/laravel/tests/TestCase.php';

include_once __DIR__ . '/ValidatorTestCase.php';